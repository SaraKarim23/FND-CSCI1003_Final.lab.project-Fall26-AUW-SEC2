"use strict";

// =====================================
// HILLGUARD 2.0 - SMART ROAD SAFETY DEMO
// =====================================

const $ = (s) => document.querySelector(s);
const get = (id) => document.getElementById(id);

// HTML ELEMENTS
const vehicleA = get("vehicleA");
const vehicleB = get("vehicleB");

const sensorA = $(".sensor-a");
const sensorB = $(".sensor-b");
const warningBeacon = get("warningBeacon");
const sceneAlert = get("sceneAlert");
const roadScene = get("roadScene");

const startButton = get("startVehicles");
const stopButton = get("stopVehicles");
const riskButton = get("riskButton");
const accidentButton = get("accidentButton");
const resetButton = get("resetButton");
const soundButton = get("soundToggle");
const dispatchButton = get("dispatchButton");

const injurySelect = get("injurySelect");
const hospitalList = get("hospitalList");
const incidentSummary = get("incidentSummary");
const dispatchResult = get("dispatchResult");
const activityLog = get("activityLog");

// SYSTEM STATES
let vehiclesStarted = false;
let collisionRisk = false;
let accidentOccurred = false;
let alertDispatched = false;
let soundEnabled = false;

let audioContext = null;
let warningInterval = null;
let accidentTimer = null;
let ambulanceTimer = null;
let ambulanceArrivalTimer = null;
let ambulanceElement = null;
let ambulanceSiren = null;

let movementFrame = null;
let movementStartTime = 0;
let movementProgress = 0;

// DEMO HOSPITAL DATA
const hospitals = [
  { name: "Nearest General Hospital", distance: 3.2, eta: 9 },
  { name: "District Medical Center", distance: 5.8, eta: 15 },
  { name: "Hill Area Emergency Hospital", distance: 8.4, eta: 22 }
];

// =====================================
// CLOCK
// =====================================

function updateClock() {
  const clock = get("clock");

  if (clock) {
    clock.textContent = new Date().toLocaleTimeString();
  }
}

updateClock();
setInterval(updateClock, 1000);

// =====================================
// NOTIFICATIONS
// =====================================

function showToast(title, message, type = "success") {
  const region = get("toastRegion");
  if (!region) return;

  const toast = document.createElement("div");
  toast.className = "toast";

  if (type === "danger") {
    toast.classList.add("danger");
  }

  const mark = document.createElement("span");
  mark.className = "toast-mark";
  mark.textContent = type === "danger" ? "!" : "✓";

  const content = document.createElement("div");

  const heading = document.createElement("strong");
  heading.textContent = title;

  const detail = document.createElement("small");
  detail.textContent = message;

  content.append(heading, detail);
  toast.append(mark, content);
  region.appendChild(toast);

  setTimeout(() => toast.remove(), 4000);
}

// =====================================
// ACTIVITY LOG
// =====================================

function addActivity(title, description, type = "normal") {
  if (!activityLog) return;

  const item = document.createElement("li");

  const dot = document.createElement("i");
  dot.className = "log-dot";

  if (type === "success") dot.classList.add("green");
  if (type === "danger") dot.classList.add("red");

  const content = document.createElement("div");

  const heading = document.createElement("b");
  heading.textContent = title;

  const detail = document.createElement("small");
  detail.textContent = description;

  content.append(heading, detail);

  const time = document.createElement("time");
  time.textContent = new Date().toLocaleTimeString();

  item.append(dot, content, time);
  activityLog.prepend(item);

  while (activityLog.children.length > 8) {
    activityLog.lastElementChild.remove();
  }

  setText("eventCount", activityLog.children.length + " EVENTS");
}

// =====================================
// DASHBOARD
// =====================================

function setText(id, value) {
  const element = get(id);

  if (element) {
    element.textContent = value;
  }
}

function updateDashboard() {
  if (accidentOccurred) {
    setText("roadStatus", "ACCIDENT");
    setText("roadStatusHint", "Emergency response required");
    setText("warningStatus", "ACTIVE");
    setText("emergencyStatus", "INCIDENT");
    setText("systemState", "ACCIDENT DETECTED");
    return;
  }

  if (collisionRisk) {
    setText("roadStatus", "DANGER");
    setText("roadStatusHint", "Collision risk detected");
    setText("warningStatus", "ACTIVE");
    setText("systemState", "COLLISION RISK");
    return;
  }

  if (vehiclesStarted) {
    setText("roadStatus", "MONITORING");
    setText("roadStatusHint", "Two vehicles moving");
    setText("warningStatus", "STANDBY");
    setText("systemState", "VEHICLES ACTIVE");
    setText("vehicleControlLabel", "MOVING");
    return;
  }

  setText("systemState", "SYSTEM ONLINE");
}

// =====================================
// SOUND SYSTEM
// =====================================

function enableAudio() {
  const AudioClass = window.AudioContext || window.webkitAudioContext;

  if (!AudioClass) {
    showToast(
      "Sound unavailable",
      "This browser does not support audio.",
      "danger"
    );

    soundEnabled = false;
    return false;
  }

  if (!audioContext) {
    audioContext = new AudioClass();
  }

  if (audioContext.state === "suspended") {
    audioContext.resume();
  }

  return true;
}

function beep(frequency = 850, duration = 200) {
  if (!soundEnabled || !audioContext) return;

  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();

  oscillator.type = "square";
  oscillator.frequency.value = frequency;

  gain.gain.setValueAtTime(0.08, audioContext.currentTime);
  gain.gain.exponentialRampToValueAtTime(
    0.001,
    audioContext.currentTime + duration / 1000
  );

  oscillator.connect(gain);
  gain.connect(audioContext.destination);

  oscillator.start();
  oscillator.stop(audioContext.currentTime + duration / 1000);
}

// Warning sound
function warningSound() {
  if (!soundEnabled) return;

  beep(1100, 250);

  setTimeout(() => beep(650, 250), 300);
  setTimeout(() => beep(1100, 250), 600);
  setTimeout(() => beep(650, 250), 900);
}

// Repeat warning siren
function startWarningAlarm() {
  stopWarningAlarm();

  if (!soundEnabled) return;

  warningSound();

  warningInterval = setInterval(() => {
    warningSound();
  }, 1600);
}

function stopWarningAlarm() {
  if (warningInterval) {
    clearInterval(warningInterval);
    warningInterval = null;
  }
}

// Ambulance siren
function startAmbulanceSiren() {
  if (!soundEnabled || !audioContext || ambulanceSiren) return;

  const carrier = audioContext.createOscillator();
  const modulator = audioContext.createOscillator();

  const modulationGain = audioContext.createGain();
  const sirenGain = audioContext.createGain();

  carrier.type = "sawtooth";
  carrier.frequency.value = 750;

  modulator.type = "sine";
  modulator.frequency.value = 1.4;

  modulationGain.gain.value = 320;
  sirenGain.gain.value = 0.045;

  modulator.connect(modulationGain);
  modulationGain.connect(carrier.frequency);

  carrier.connect(sirenGain);
  sirenGain.connect(audioContext.destination);

  carrier.start();
  modulator.start();

  ambulanceSiren = {
    carrier,
    modulator
  };
}

function stopAmbulanceSiren() {
  if (!ambulanceSiren) return;

  try {
    ambulanceSiren.carrier.stop();
    ambulanceSiren.modulator.stop();
  } catch (error) {
    // Already stopped.
  }

  ambulanceSiren = null;
}

// Sound button
soundButton.addEventListener("click", async () => {
  if (!soundEnabled) {
    soundEnabled = true;

    if (!enableAudio()) return;

    if (audioContext.state === "suspended") {
      await audioContext.resume();
    }

    soundButton.textContent = "🔊";
    soundButton.setAttribute("aria-pressed", "true");

    beep(700, 150);

    showToast("Sound ON", "Audio alerts are enabled.");

    if (collisionRisk && !accidentOccurred) {
      startWarningAlarm();
    }

    if (ambulanceElement && ambulanceElement.dataset.arrived !== "true") {
      startAmbulanceSiren();
    }
  } else {
    soundEnabled = false;

    soundButton.textContent = "🔇";
    soundButton.setAttribute("aria-pressed", "false");

    stopWarningAlarm();
    stopAmbulanceSiren();

    showToast("Sound OFF", "Audio alerts are disabled.");
  }
});

// =====================================
// VEHICLE ROAD TRACKING
// =====================================

function getRoadPosition(progress, offset = 0) {
  const svg = roadScene?.querySelector("svg");
  const path = roadScene?.querySelector(".road-center");

  if (!svg || !path || !roadScene) return null;

  const totalLength = path.getTotalLength();

  const distance = Math.max(
    0,
    Math.min(totalLength, progress * totalLength)
  );

  const point = path.getPointAtLength(distance);

  const before = path.getPointAtLength(
    Math.max(0, distance - 1)
  );

  const after = path.getPointAtLength(
    Math.min(totalLength, distance + 1)
  );

  const dx = after.x - before.x;
  const dy = after.y - before.y;

  const length = Math.sqrt(dx * dx + dy * dy) || 1;

  const normalX = -dy / length;
  const normalY = dx / length;

  const finalPoint = svg.createSVGPoint();

  finalPoint.x = point.x + normalX * offset;
  finalPoint.y = point.y + normalY * offset;

  const screenPoint = finalPoint.matrixTransform(
    path.getScreenCTM()
  );

  const sceneRect = roadScene.getBoundingClientRect();

  return {
    x: screenPoint.x - sceneRect.left,
    y: screenPoint.y - sceneRect.top
  };
}

function placeVehicle(element, progress, offset = 0) {
  if (!element) return;

  const position = getRoadPosition(progress, offset);

  if (!position) return;

  element.style.left = position.x + "px";
  element.style.top = position.y + "px";
  element.style.right = "auto";
  element.style.transform = "translate(-50%, -50%)";
  element.style.transition = "none";
}

function updateVehiclePositions(progress) {
  // Both vehicles approach the same collision point.
  const laneOffset = 10 * Math.max(0, 1 - progress);

  const positionA = 0.06 + progress * 0.44;
  const positionB = 0.94 - progress * 0.44;

  placeVehicle(vehicleA, positionA, -laneOffset);
  placeVehicle(vehicleB, positionB, laneOffset);
}

// =====================================
// VEHICLE ANIMATION
// =====================================

function stopMovementAnimation() {
  if (movementFrame) {
    cancelAnimationFrame(movementFrame);
    movementFrame = null;
  }
}

function animateVehicles(timestamp) {
  if (!vehiclesStarted || accidentOccurred) {
    movementFrame = null;
    return;
  }

  if (!movementStartTime) {
    movementStartTime = timestamp;
  }

  const elapsed = timestamp - movementStartTime;

  // Full approach takes 12 seconds.
  movementProgress = Math.min(elapsed / 12000, 1);

  updateVehiclePositions(movementProgress);

  // Warning activates BEFORE the blind turn.
  // Vehicles continue moving after warning.
  if (movementProgress >= 0.40 && !collisionRisk) {
    simulateRisk();
  }

  // Collision point reached.
  if (movementProgress >= 1) {
    movementFrame = null;
    updateVehiclePositions(1);
    simulateAccident();
    return;
  }

  movementFrame = requestAnimationFrame(animateVehicles);
}

function startVehicleAnimation() {
  stopMovementAnimation();

  movementStartTime = 0;
  movementProgress = 0;

  updateVehiclePositions(0);

  movementFrame = requestAnimationFrame(animateVehicles);
}

// =====================================
// START VEHICLES
// =====================================

function startVehicles() {
  if (accidentOccurred) return;

  if (vehiclesStarted) {
    showToast("Already moving", "Vehicles are already active.");
    return;
  }

  vehiclesStarted = true;

  vehicleA.classList.add("is-moving");
  vehicleB.classList.add("is-moving");

  setText("vehicleAState", "MOVING");
  setText("vehicleBState", "MOVING");

  startButton.disabled = true;
  stopButton.disabled = false;

  startVehicleAnimation();
  updateDashboard();

  addActivity(
    "Vehicles started",
    "Both vehicles are following the hill-road path.",
    "success"
  );

  showToast("Vehicles moving", "Both vehicles have started.");

  beep(600, 150);
}

// =====================================
// STOP VEHICLES
// =====================================

function stopVehicles() {
  if (!vehiclesStarted || accidentOccurred) return;

  vehiclesStarted = false;

  stopMovementAnimation();
  stopWarningAlarm();

  vehicleA.classList.remove("is-moving");
  vehicleB.classList.remove("is-moving");

  setText("vehicleAState", "STOPPED");
  setText("vehicleBState", "STOPPED");
  setText("vehicleControlLabel", "STOPPED");

  startButton.disabled = false;
  stopButton.disabled = true;

  setText("roadStatus", "STOPPED");
  setText("roadStatusHint", "Vehicle movement paused");

  addActivity(
    "Vehicles stopped",
    "Vehicle movement paused.",
    "normal"
  );

  showToast("Vehicles stopped", "Both vehicles have stopped.");
}

// =====================================
// COLLISION RISK WARNING
// =====================================

function simulateRisk() {
  if (!vehiclesStarted || collisionRisk || accidentOccurred) return;

  collisionRisk = true;

  // IMPORTANT:
  // Do not stop vehicle movement here.

  vehicleA.classList.add("is-warning");
  vehicleB.classList.add("is-warning");

  sensorA?.classList.add("is-warning");
  sensorB?.classList.add("is-warning");

  warningBeacon?.classList.add("is-active");

  sceneAlert.textContent = "⚠ COLLISION RISK — SLOW DOWN";
  sceneAlert.classList.remove("hidden");

  setText("vehicleAState", "WARNING!");
  setText("vehicleBState", "WARNING!");
  setText("riskControlLabel", "WARNING ACTIVE");

  updateDashboard();

  addActivity(
    "Collision risk detected",
    "Blind-turn warning activated by the sensors.",
    "danger"
  );

  showToast(
    "BLIND TURN WARNING",
    "Warning signal activated. Collision risk detected!",
    "danger"
  );

  startWarningAlarm();
}

// =====================================
// HOSPITAL RANKING
// =====================================

function displayHospitals() {
  if (!hospitalList) return;

  hospitalList.replaceChildren();

  hospitals
    .slice()
    .sort((a, b) => a.distance - b.distance)
    .forEach((hospital, index) => {
      const card = document.createElement("div");
      card.className = "hospital-card";

      const rank = document.createElement("span");
      rank.className = "hospital-rank";
      rank.textContent = "#" + (index + 1);

      const details = document.createElement("div");

      const name = document.createElement("b");
      name.textContent = hospital.name;

      const info = document.createElement("small");
      info.textContent =
        "Sample directory • " + hospital.eta + " min estimated";

      details.append(name, info);

      const distance = document.createElement("span");
      distance.className = "hospital-distance";
      distance.textContent = hospital.distance.toFixed(1) + " km";

      card.append(rank, details, distance);
      hospitalList.appendChild(card);
    });
}

// =====================================
// AMBULANCE
// =====================================

function showAmbulance() {
  if (ambulanceElement) {
    ambulanceElement.remove();
  }

  ambulanceElement = document.createElement("div");
  ambulanceElement.className = "ambulance";
  ambulanceElement.innerHTML =
    "<span>🚑</span><small>AMBULANCE</small>";

  ambulanceElement.dataset.arrived = "false";

  roadScene.appendChild(ambulanceElement);

  // Siren starts when ambulance begins moving.
  startAmbulanceSiren();

  ambulanceTimer = setTimeout(() => {
    if (!ambulanceElement) return;

    ambulanceElement.classList.add("ambulance-arrived");

    // Wait for the CSS movement to finish.
    ambulanceArrivalTimer = setTimeout(() => {
      if (!ambulanceElement) return;

      ambulanceElement.dataset.arrived = "true";

      stopAmbulanceSiren();

      showToast(
        "AMBULANCE ARRIVED",
        "The demo ambulance has reached the incident location."
      );

      addActivity(
        "Ambulance arrived",
        "The simulated ambulance reached the incident location.",
        "success"
      );
    }, 4200);

  }, 100);
}

// =====================================
// ACCIDENT SIMULATION
// =====================================

function simulateAccident() {
  if (!vehiclesStarted || accidentOccurred) return;

  accidentOccurred = true;
  collisionRisk = true;

  stopMovementAnimation();
  stopWarningAlarm();

  const injured = injurySelect?.value || "2";

  vehicleA.classList.add("is-warning", "is-crashed");
  vehicleB.classList.add("is-warning", "is-crashed");

  sensorA?.classList.add("is-warning");
  sensorB?.classList.add("is-warning");

  warningBeacon?.classList.add("is-active");

  sceneAlert.textContent = "🚨 ACCIDENT DETECTED";
  sceneAlert.classList.remove("hidden");

  setText("vehicleAState", "ACCIDENT");
  setText("vehicleBState", "ACCIDENT");

  setText("incidentTitle", "ACCIDENT REPORTED");

  setText(
    "incidentText",
    "A simulated accident has occurred. Emergency response is required."
  );

  setText("incidentTime", new Date().toLocaleTimeString());
  setText("injuredEstimate", injured + " people");

  incidentSummary?.classList.add("is-danger");

  setText("incidentBadge", "ACTIVE INCIDENT");
  setText("accidentControlLabel", "ACCIDENT");
  setText("emergencyStatus", "ACTIVE");

  updateDashboard();

  addActivity(
    "ACCIDENT DETECTED",
    "A simulated collision has occurred.",
    "danger"
  );

  addActivity(
    "Injury estimate",
    "Estimated injured people: " + injured,
    "danger"
  );

  showToast(
    "EMERGENCY ALERT",
    "Accident detected. Estimated injured people: " + injured,
    "danger"
  );

  warningSound();

  displayHospitals();
  updateWorkflow(1);

  // Ambulance arrives after the collision.
  ambulanceTimer = setTimeout(showAmbulance, 700);

  setText("incidentLocation", "Hill Road / Sector 04 (demo)");

  startButton.disabled = true;
  stopButton.disabled = true;
  riskButton.disabled = true;
  accidentButton.disabled = true;
  dispatchButton.disabled = false;

  addActivity(
    "Hospitals ranked",
    "Sample hospitals sorted by estimated distance.",
    "success"
  );
}

// =====================================
// RESPONSE WORKFLOW
// =====================================

function updateWorkflow(activeStep) {
  const steps = document.querySelectorAll(".workflow li");

  steps.forEach((step, index) => {
    step.classList.remove("done", "active");

    const status = step.querySelector("em");
    if (!status) return;

    if (index < activeStep) {
      step.classList.add("done");
      status.textContent = "COMPLETED";
    } else if (index === activeStep) {
      step.classList.add("active");
      status.textContent = "ACTIVE";
    } else {
      status.textContent = "WAITING";
    }
  });
}

// =====================================
// EMERGENCY DEMO ALERT
// =====================================

function dispatchEmergencyAlert() {
  if (!accidentOccurred || alertDispatched) return;

  alertDispatched = true;

  const injured = injurySelect?.value || "2";
  const nearest = hospitals[0];

  updateWorkflow(4);

  dispatchResult.classList.remove("hidden");

  dispatchResult.textContent =
    "✓ DEMO ALERT PREPARED — " +
    nearest.name +
    " | " +
    nearest.distance +
    " km | Injured estimate: " +
    injured +
    ". No real hospital was contacted.";

  dispatchButton.textContent = "✓ DEMO ALERT PREPARED";
  dispatchButton.disabled = true;

  setText("emergencyStatus", "DEMO READY");

  addActivity(
    "Emergency demo alert prepared",
    "Sample emergency notification created.",
    "success"
  );

  showToast(
    "DEMO ALERT READY",
    "The sample emergency message has been prepared."
  );
}

// =====================================
// RESET SIMULATION
// =====================================

function resetSimulation() {
  clearTimeout(accidentTimer);
  clearTimeout(ambulanceTimer);
  clearTimeout(ambulanceArrivalTimer);

  stopMovementAnimation();
  stopWarningAlarm();
  stopAmbulanceSiren();

  vehiclesStarted = false;
  collisionRisk = false;
  accidentOccurred = false;
  alertDispatched = false;

  movementProgress = 0;
  movementStartTime = 0;

  vehicleA.classList.remove(
    "is-moving",
    "is-warning",
    "is-crashed"
  );

  vehicleB.classList.remove(
    "is-moving",
    "is-warning",
    "is-crashed"
  );

  sensorA?.classList.remove("is-warning");
  sensorB?.classList.remove("is-warning");

  warningBeacon?.classList.remove("is-active");
  sceneAlert?.classList.add("hidden");

  if (ambulanceElement) {
    ambulanceElement.remove();
    ambulanceElement = null;
  }

  updateVehiclePositions(0);

  setText("vehicleAState", "APPROACH A");
  setText("vehicleBState", "APPROACH B");

  setText("roadStatus", "CLEAR");
  setText("roadStatusHint", "No immediate conflict detected");
  setText("warningStatus", "STANDBY");
  setText("emergencyStatus", "READY");

  setText("vehicleControlLabel", "IDLE");
  setText("riskControlLabel", "STANDBY");
  setText("accidentControlLabel", "STANDBY");

  setText("incidentBadge", "NO ACTIVE INCIDENT");
  setText("incidentTitle", "All clear on this route");

  setText(
    "incidentText",
    "No accident has been reported. Emergency workflow is on standby."
  );

  setText("incidentTime", "—");
  setText("injuredEstimate", "—");
  setText("incidentLocation", "Hill Road / Sector 04 (demo)");

  incidentSummary?.classList.remove("is-danger");

  hospitalList?.replaceChildren();

  if (hospitalList) {
    const empty = document.createElement("div");
    empty.className = "empty-hospitals";

    empty.textContent =
      "Hospital ranking will appear after an accident is simulated.";

    hospitalList.appendChild(empty);
  }

  updateWorkflow(-1);

  startButton.disabled = false;
  stopButton.disabled = true;
  riskButton.disabled = false;
  accidentButton.disabled = false;

  dispatchButton.disabled = true;
  dispatchButton.textContent = "Prepare emergency alert";

  dispatchResult?.classList.add("hidden");

  if (dispatchResult) {
    dispatchResult.textContent = "";
  }

  updateDashboard();

  setText("roadStatus", "CLEAR");
  setText("systemState", "SYSTEM ONLINE");

  addActivity(
    "Simulation reset",
    "HillGuard is ready for a new demonstration.",
    "success"
  );

  showToast("SYSTEM RESET", "All simulation states have been reset.");
}

// =====================================
// BUTTON CONNECTIONS
// =====================================

startButton.addEventListener("click", startVehicles);
stopButton.addEventListener("click", stopVehicles);
riskButton.addEventListener("click", simulateRisk);

accidentButton.addEventListener("click", () => {
  if (!vehiclesStarted || accidentOccurred) {
    simulateAccident();
    return;
  }

  if (!collisionRisk) {
    simulateRisk();

    accidentTimer = setTimeout(() => {
      simulateAccident();
    }, 1800);
  } else {
    simulateAccident();
  }
});

resetButton.addEventListener("click", resetSimulation);
dispatchButton.addEventListener("click", dispatchEmergencyAlert);

// Clear activity log
get("clearLogButton")?.addEventListener("click", () => {
  activityLog?.replaceChildren();
  setText("eventCount", "0 EVENTS");
});

// =====================================
// INITIAL STATE
// =====================================

stopButton.disabled = true;
dispatchButton.disabled = true;

updateWorkflow(-1);

requestAnimationFrame(() => {
  updateVehiclePositions(0);
});

addActivity(
  "Monitoring started",
  "HillGuard demo system is online.",
  "success"
);

console.log("HillGuard 2.0 is ready.");