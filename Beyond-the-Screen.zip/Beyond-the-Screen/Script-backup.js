
// MOBILE NAVIGATION

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

// Open and close the mobile menu
menuToggle.addEventListener("click", function () {

    navLinks.classList.toggle("active");

    const isOpen = navLinks.classList.contains("active");

    menuToggle.setAttribute("aria-expanded", isOpen);

    menuToggle.textContent = isOpen ? "✕" : "☰";

});


// Close menu after selecting a navigation link

const navigationItems = document.querySelectorAll(".nav-links a");

navigationItems.forEach(function (item) {

    item.addEventListener("click", function () {

        navLinks.classList.remove("active");

        menuToggle.setAttribute("aria-expanded", "false");

        menuToggle.textContent = "☰";

    });

});


// Welcome message in browser console

console.log("Welcome to Beyond the Screen!");
console.log("Every story deserves to be understood.");


/* =================================
   BEYOND THE SCREEN
   STORY 01: THE SILENT CLASSMATE
================================= */

const storyModal = document.getElementById("storyModal");
const storyContent = document.getElementById("storyContent");
const closeStory = document.getElementById("closeStory");

let selectedChoice = null;

// Story data
const silentClassmate = {
    introduction: `
        <h2>Some silences have stories.</h2>

        <p>
            You are in a university classroom. There is a student
            who always sits alone, rarely speaks, and never joins
            group discussions.
        </p>

        <p>
            Today, your teacher asks everyone to form groups.
            Once again, this student remains alone.
        </p>

        <p><strong>What would you do?</strong></p>
    `,

    choices: [
        {
            text: "A. Assume they are unfriendly.",
            outcome: `
                You decide not to approach them.
                You assume they simply don't want company.
            `
        },
        {
            text: "B. Leave them alone.",
            outcome: `
                You think giving them space is the best option.
                You continue with your own group.
            `
        },
        {
            text: "C. Approach them kindly.",
            outcome: `
                You walk over, smile, and ask if they would
                like to join your group.
            `
        }
    ],

    hiddenStory: `
        <p>
            What you didn't know was that this student had recently
            moved to a new city. Their family was far away, and
            financial and personal difficulties had made university
            life harder than anyone could see.
        </p>

        <p>
            They wanted to make friends but were afraid of being
            judged for their silence, their accent, and their
            unfamiliarity with the environment.
        </p>

        <p>
            Their silence was not a sign of arrogance.
            It was simply one part of a much bigger story.
        </p>
    `
};


// Open story when someone clicks Explore Story
document.querySelectorAll('[data-story="silent"]').forEach(link => {

    link.addEventListener("click", function(event) {

        event.preventDefault();
        openSilentStory();

    });

});


// Show the first screen
function openSilentStory() {

    selectedChoice = null;

    storyModal.classList.add("active");
    storyModal.setAttribute("aria-hidden", "false");

    document.body.style.overflow = "hidden";

    showIntroduction();

}


// Introduction and choices
function showIntroduction() {

    storyContent.innerHTML = `
        <div class="story-progress">
            <div class="story-progress-fill" style="width: 25%"></div>
        </div>

        ${silentClassmate.introduction}

        <div class="story-choices">

            ${silentClassmate.choices.map((choice, index) => `
                <button class="story-choice" data-choice="${index}">
                    ${choice.text}
                </button>
            `).join("")}

        </div>
    `;

    document.querySelectorAll("[data-choice]").forEach(button => {

        button.addEventListener("click", function() {

            const choiceIndex = Number(this.dataset.choice);

            selectedChoice = silentClassmate.choices[choiceIndex];

            showOutcome();

        });

    });

}


// Show the consequence of the selected choice
function showOutcome() {

    storyContent.innerHTML = `
        <div class="story-progress">
            <div class="story-progress-fill" style="width: 50%"></div>
        </div>

        <h2>Your perspective</h2>

        <p>${selectedChoice.outcome}</p>

        <p>But is this all there is to the story?</p>

        <button class="story-next" id="revealButton">
            See what you couldn't see →
        </button>
    `;

    document.getElementById("revealButton").addEventListener(
        "click",
        showHiddenStory
    );

}


// Reveal the hidden story
function showHiddenStory() {

    storyContent.innerHTML = `
        <div class="story-progress">
            <div class="story-progress-fill" style="width: 75%"></div>
        </div>

        <h2>See it from their side.</h2>

        <div class="story-reveal">

            <h3>The story behind the silence</h3>

            ${silentClassmate.hiddenStory}

        </div>

        <p>
            Sometimes, what we see is only a small part of
            what someone is experiencing.
        </p>

        <button class="story-next" id="reflectButton">
            Reflect on this story →
        </button>
    `;

    document.getElementById("reflectButton").addEventListener(
        "click",
        showReflection
    );

}


// Reflection screen
function showReflection() {

    storyContent.innerHTML = `
        <div class="story-progress">
            <div class="story-progress-fill" style="width: 100%"></div>
        </div>

        <h2>A moment to reflect.</h2>

        <p>
            Did discovering the hidden story change how you
            viewed the classmate?
        </p>

        <div class="story-reflection">

            <label for="reflectionAnswer">
                Write your thoughts:
            </label>

            <textarea
                id="reflectionAnswer"
                placeholder="I learned that..."
            ></textarea>

        </div>

        <button class="story-next" id="finishStory">
            Complete story ✓
        </button>
    `;

    document.getElementById("finishStory").addEventListener(
        "click",
        completeStory
    );

}


// Complete story and save progress
function completeStory() {

    const answer = document.getElementById("reflectionAnswer").value;

    localStorage.setItem("silentClassmateCompleted", "true");

    localStorage.setItem("silentClassmateReflection", answer);

    storyContent.innerHTML = `
        <h2>Thank you for looking beyond. 🤍</h2>

        <p>
            You have completed your first Beyond the Screen story.
        </p>

        <div class="story-reveal">

            <h3>Remember this:</h3>

            <p>
                Everyone has a story we cannot see.
                A little understanding can make a big difference.
            </p>

        </div>

        <button class="story-next" id="finishButton">
            Return to homepage
        </button>
    `;

    document.getElementById("finishButton").addEventListener(
        "click",
        closeStoryWindow
    );

}


// Close story
function closeStoryWindow() {

    storyModal.classList.remove("active");

    storyModal.setAttribute("aria-hidden", "true");

    document.body.style.overflow = "";

}

closeStory.addEventListener("click", closeStoryWindow);


// Close when clicking outside the story box
storyModal.addEventListener("click", function(event) {

    if (event.target === storyModal) {
        closeStoryWindow();
    }

});
