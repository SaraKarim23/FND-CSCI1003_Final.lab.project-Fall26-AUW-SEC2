
/* =====================================
   1. SKIN TYPE ANALYZER
===================================== */

document.getElementById("skinForm").addEventListener("submit", function(event) {

    event.preventDefault();

    let skin = document.getElementById("skinType").value;
    let concern = document.getElementById("skinConcern").value;

    let result = "";

    if (skin === "" || concern === "") {
        result = "Please select your skin type and concern.";
    } else {
        result = `
            <h3>Your Skin Analysis 🌸</h3>
            <p><strong>Skin Type:</strong> ${skin}</p>
            <p><strong>Main Concern:</strong> ${concern}</p>
            <p>Choose gentle skincare products that suit your needs.
            Everyone's skin is different, so keep your routine comfortable.</p>
        `;
    }

    document.getElementById("skinResult").innerHTML = result;

});


/* =====================================
   2. PRODUCT RECOMMENDATIONS
===================================== */

document.getElementById("productBtn").addEventListener("click", function() {

    let skin = document.getElementById("productSkin").value;

    let recommendation = "";

    if (skin === "") {
        recommendation = "Please select your skin type first.";
    }

    else if (skin === "oily") {
        recommendation = `
            <h3>For Oily Skin 🌸</h3>
            <p>• Gentle gel cleanser</p>
            <p>• Lightweight moisturizer</p>
            <p>• Broad-spectrum sunscreen</p>
            <p>• Non-comedogenic skincare products</p>
        `;
    }

    else if (skin === "dry") {
        recommendation = `
            <h3>For Dry Skin 🌷</h3>
            <p>• Gentle hydrating cleanser</p>
            <p>• Moisturizer with hydrating ingredients</p>
            <p>• Broad-spectrum sunscreen</p>
            <p>• Fragrance-free skincare products</p>
        `;
    }

    else if (skin === "combination") {
        recommendation = `
            <h3>For Combination Skin 💗</h3>
            <p>• Gentle daily cleanser</p>
            <p>• Lightweight moisturizer</p>
            <p>• Broad-spectrum sunscreen</p>
            <p>• Products suitable for different skin areas</p>
        `;
    }

    else if (skin === "sensitive") {
        recommendation = `
            <h3>For Sensitive Skin 🌼</h3>
            <p>• Fragrance-free gentle cleanser</p>
            <p>• Simple moisturizer</p>
            <p>• Gentle sunscreen</p>
            <p>• Patch-test new products</p>
        `;
    }

    else if (skin === "normal") {
        recommendation = `
            <h3>For Normal Skin ✨</h3>
            <p>• Gentle cleanser</p>
            <p>• Daily moisturizer</p>
            <p>• Broad-spectrum sunscreen</p>
            <p>• Simple skincare routine</p>
        `;
    }

    document.getElementById("productResults").innerHTML = recommendation;

});


/* =====================================
   3. HEALTHY FOOD AND NUTRITION GUIDE
===================================== */

document.getElementById("nutritionForm").addEventListener("submit", function(event) {

    event.preventDefault();

    let preference = document.getElementById("foodPreference").value;
    let goal = document.getElementById("foodGoal").value;

    let food = "";

    if (preference === "" || goal === "") {
        food = "Please select both options.";
    }

    else if (preference === "vegetarian") {
        food = `
            <h3>Vegetarian Food Ideas 🥗</h3>
            <p>• Rice with vegetables and lentils</p>
            <p>• Fresh seasonal fruits</p>
            <p>• Milk or yogurt</p>
            <p>• Nuts and seeds</p>
            <p>• Vegetable soup</p>
        `;
    }

    else if (preference === "non-vegetarian") {
        food = `
            <h3>Balanced Food Ideas 🍎</h3>
            <p>• Rice with fish or chicken</p>
            <p>• Fresh vegetables</p>
            <p>• Seasonal fruits</p>
            <p>• Eggs</p>
            <p>• Milk or yogurt</p>
        `;
    }

    else if (preference === "vegan") {
        food = `
            <h3>Plant-Based Food Ideas 🌱</h3>
            <p>• Rice and lentils</p>
            <p>• Beans and chickpeas</p>
            <p>• Fresh fruits</p>
            <p>• Nuts and seeds</p>
            <p>• Green vegetables</p>
        `;
    }

    food += `
        <p class="result-note">
            Your selected interest: ${goal}.
            Enjoy a variety of foods and balanced meals.
        </p>
    `;

    document.getElementById("nutritionResults").innerHTML = food;

});


/* =====================================
   4. PERSONALIZED DAILY ROUTINE
===================================== */

document.getElementById("routineBtn").addEventListener("click", function() {

    let skin = document.getElementById("routineSkin").value;

    let routine = "";

    if (skin === "") {
        routine = "Please select your skin type.";
    }

    else {

        let extraTip = "";

        if (skin === "oily") {
            extraTip = "Choose lightweight products that feel comfortable on your skin.";
        }

        else if (skin === "dry") {
            extraTip = "Choose a gentle cleanser and a moisturizer that keeps your skin comfortable.";
        }

        else if (skin === "sensitive") {
            extraTip = "Choose fragrance-free products and patch-test new products.";
        }

        else if (skin === "combination") {
            extraTip = "Use gentle products and pay attention to how different areas of your skin feel.";
        }

        else {
            extraTip = "Keep your routine simple and consistent.";
        }

        routine = `
            <h3>☀️ Morning Routine</h3>
            <p>1. Wash your face with a gentle cleanser.</p>
            <p>2. Apply a suitable moisturizer.</p>
            <p>3. Finish with broad-spectrum sunscreen.</p>

            <br>

            <h3>🌙 Evening Routine</h3>
            <p>1. Gently cleanse your face.</p>
            <p>2. Apply moisturizer.</p>
            <p>3. Give your skin time to rest.</p>

            <br>

            <h3>Your Skin Care Note 💗</h3>
            <p>${extraTip}</p>
        `;
    }

    document.getElementById("routineResult").innerHTML = routine;

});


/* =====================================
   5. DAILY WELLNESS TRACKER
===================================== */

// WATER TRACKER

let water = 0;

document.getElementById("addWater").addEventListener("click", function() {

    water = water + 1;

    document.getElementById("waterCount").innerHTML = water;

});


document.getElementById("resetWater").addEventListener("click", function() {

    water = 0;

    document.getElementById("waterCount").innerHTML = water;

});


// DAILY HABIT CHECKLIST

let habits = document.querySelectorAll(".habitCheck");

function updateHabits() {

    let completed = 0;

    for (let i = 0; i < habits.length; i++) {

        if (habits[i].checked) {
            completed = completed + 1;
        }

    }

    document.getElementById("habitResult").innerHTML =
        completed + " out of " + habits.length +
        " wellness habits completed 🌸";

}

for (let i = 0; i < habits.length; i++) {

    habits[i].addEventListener("change", updateHabits);

}


/* =====================================
   6. BEAUTY AND WELLNESS TIPS
===================================== */

let tips = [

    "Remember to cleanse your face gently every day. 🌸",

    "Use sunscreen during the daytime. ☀️",

    "Drink water regularly throughout the day. 💧",

    "Get enough rest and maintain a regular sleep routine. 🌙",

    "Choose skincare products that feel comfortable on your skin. 💗",

    "Eat a variety of nutritious foods. 🍎",

    "Avoid trying too many new skincare products at once. ✨",

    "Take a little time for yourself every day. 🌷",

    "Patch-test new skincare products before regular use. 💕",

    "Keep your skincare routine simple and consistent. 🌼"

];


document.getElementById("newTip").addEventListener("click", function() {

    let randomNumber = Math.floor(Math.random() * tips.length);

    document.getElementById("tipText").innerHTML =
        tips[randomNumber];

});
